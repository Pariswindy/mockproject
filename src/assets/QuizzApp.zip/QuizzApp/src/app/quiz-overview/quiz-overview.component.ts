import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../services/get-data.service';

@Component({
  selector: 'app-quiz-overview',
  templateUrl: './quiz-overview.component.html',
  styleUrls: ['./quiz-overview.component.scss']
})
export class QuizOverviewComponent implements OnInit {

  listData: any;
  constructor(private myService: GetDataService) {
    this.listData = this.myService.dataRes;
  }

  ngOnInit(): void {
  }

}
