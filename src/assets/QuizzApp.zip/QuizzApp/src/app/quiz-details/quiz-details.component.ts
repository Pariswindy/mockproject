import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../services/get-data.service';
import { Router } from '@angular/router';

export interface UserAnswer {
  _id: string;
  correct: string[];
}
export interface Body {
  code: string;
  userAnswers: UserAnswer[];
}
@Component({
  selector: 'app-quiz-details',
  templateUrl: './quiz-details.component.html',
  styleUrls: ['./quiz-details.component.scss'],
})
export class QuizDetailsComponent implements OnInit {
  numberQues: number = 1;
  listData: any;
  testName!: string;
  time: any;
  minutes!: number;
  seconds!: number;

  preClass: boolean = true;
  nextClass: boolean = false;
  submitClass = 'btn btn-primary d-none';
  next = 'btn btn-primary';
  body: Body = {
    code: 'fafafa',
    userAnswers: [],
  };
  interval: any;
  setInterval = setInterval;

  constructor(private myService: GetDataService, private route: Router) {
    this.listData = this.myService.dataRes.questions;
    this.testName = this.myService.dataRes.testName;
    this.time = this.myService.dataRes.duration * 60;
  }

  ngOnInit(): void {
    this.changeTime();
    setInterval( () => this.changeTime(), 1000);
  }

  previousQ() {
    if (this.numberQues == 2) {
      this.preClass = true;
      this.numberQues--;
    } else {
      this.numberQues--;
      this.nextClass = false;
    }
    this.submitClass = 'btn btn-primary d-none';
    this.next = 'btn btn-primary';
  }

  nextQ() {
    if (this.numberQues == 19) {
      this.nextClass = true;
      this.numberQues++;
      this.submitClass = 'btn btn-primary';
      this.next = 'd-none';
    } else {
      this.numberQues++;
      this.preClass = false;
    }
  }

  submit() {
    this.listData.forEach((item: any, index: any) => {
      if (!this.body.userAnswers[index]) {
        this.body.userAnswers[index] = {
          _id: this.listData[this.numberQues - 1]['_id'],
          correct: [],
        };
      }
    });
    this.myService.submitResult(this.body).subscribe((res) => {
      this.myService.result.next(res);
    });
    this.route.navigate(['/quiz-result']);
  }

  getCorrect(e: any) {
    if (!this.listData[this.numberQues - 1].multi) {
      this.body.userAnswers[this.numberQues - 1] = {
        _id: this.listData[this.numberQues - 1]['_id'],
        correct: [e],
      };
    } else {
        if (this.body.userAnswers[this.numberQues - 1]) {
          if(this.body.userAnswers[this.numberQues - 1].correct.indexOf(e) === -1) {
            this.body.userAnswers[this.numberQues - 1]['correct'].push(e);
          }
        } else {
          this.body.userAnswers[this.numberQues - 1] = {
            _id: this.listData[this.numberQues - 1]['_id'],
            correct: [e],
          };
        }
    }
    console.log(this.body.userAnswers);
    
  }

  handleCheck(e: string) {
    if (!this.body.userAnswers[this.numberQues - 1]) {
      return false;
    } else {
      if(this.body.userAnswers[this.numberQues - 1].correct.indexOf(e) === -1) {
        return false;
      } else {
        return true;
      }
    }
  }

  changeTime() {
    this.minutes = Math.floor(this.time/60);
    this.seconds = this.time - this.minutes*60;
    this.time--;
    console.log(this.time);
  }
}
