import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { GetDataService } from '../services/get-data.service';

@Component({
  selector: 'app-quiz-result',
  templateUrl: './quiz-result.component.html',
  styleUrls: ['./quiz-result.component.scss']
})
export class QuizResultComponent implements OnInit {

  resultDetail: any;
  testName: string = "";
  constructor(private myService: GetDataService) {
    this.myService.result.subscribe(res => {
      this.resultDetail = res;
      console.log(res);
      
    })
    this.testName = this.myService.dataRes.testName;
   }

  ngOnInit(): void {
    
  }

}
