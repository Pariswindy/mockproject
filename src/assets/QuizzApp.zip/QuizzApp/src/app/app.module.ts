import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';
import { GetDataService } from './services/get-data.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuizInputComponent } from './quiz-input/quiz-input.component';
import { QuizOverviewComponent } from './quiz-overview/quiz-overview.component';
import { QuizDetailsComponent } from './quiz-details/quiz-details.component';
import { QuizResultComponent } from './quiz-result/quiz-result.component';

import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    QuizInputComponent,
    QuizOverviewComponent,
    QuizDetailsComponent,
    QuizResultComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
