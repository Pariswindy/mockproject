import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuizDetailsComponent } from './quiz-details/quiz-details.component';
import { QuizInputComponent } from './quiz-input/quiz-input.component';
import { QuizOverviewComponent } from './quiz-overview/quiz-overview.component';
import { QuizResultComponent } from './quiz-result/quiz-result.component';

const routes: Routes = [
  {path: "quiz-input", component: QuizInputComponent},
  {path: "quiz-overview", component: QuizOverviewComponent},
  {path: "quiz-details", component: QuizDetailsComponent},
  {path: "quiz-result", component: QuizResultComponent},
  {path: "", redirectTo: "quiz-input", pathMatch: "full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
