import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../services/get-data.service';
import { FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quiz-input',
  templateUrl: './quiz-input.component.html',
  styleUrls: ['./quiz-input.component.scss']
})
export class QuizInputComponent implements OnInit {

  quizCode = new FormControl("", Validators.required);
  constructor(private myService: GetDataService, private route: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    this.myService.checkAuth({code: this.quizCode.value}).subscribe(res => {
      if(res) {
        this.myService.dataRes = res;
        this.route.navigate(["/quiz-overview"]);
        
      }
    });
  }
}
