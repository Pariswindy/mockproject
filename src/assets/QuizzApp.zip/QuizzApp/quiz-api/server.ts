import express, { Request, Response, NextFunction } from 'express';
import bodyParser from 'body-parser';

import questions from './data/questions.json';

import entryCodes from './data/entry-codes.json';
import { UserAnswer } from './answer.model';

console.log(questions);
console.log(entryCodes);

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Enable CORS
app.use(function (request: Request, response: Response, next: NextFunction) {
  response.header('Access-Control-Allow-Origin', '*');
  response.header(
    'Access-Control-Allow-Headers',
    'Origin, Authorization, X-Requested-With, X-XSRF-TOKEN, Content-Type, Accept'
  );
  response.header(
    'Access-Control-Allow-Methods',
    'GET,PUT,POST,DELETE,PATCH,OPTIONS'
  );
  next();
});

// start quiz
app.post('/api/quiz/start', (request: Request, response: Response) => {
  const { code } = request.body;

  if (!code) {
    return response.status(400).json({
      message: 'Missing parameter code'
    });
  }

  const foundEntryCode = entryCodes.find(
    (entryCode) => entryCode.code === code
  );

  if (!foundEntryCode) {
    return response.status(400).json({
      message: `Code: ${code} is invalid`
    });
  }

  return response.json({
    testName: foundEntryCode.testName,
    duration: foundEntryCode.duration,
    passScore: foundEntryCode.passScore,
    account: foundEntryCode.account,
    questions: questions.map((question) => ({
      _id: question._id,
      type: question.type,
      language: question.language,
      question: question.question,
      level: question.level,
      options: question.options,
      multi: question.multi
    }))
  });
});

app.post('/api/quiz/end', (request: Request, response: Response) => {
  try {
    const {
      userAnswers,
      code
    }: { userAnswers: UserAnswer[]; code: string } = request.body;

    if (!userAnswers || !code) {
      throw new Error('Invalid parameter');
    }

    const foundEntryCode = entryCodes.find(
      (entryCode) => entryCode.code === code
    );

    if (!foundEntryCode) {
      throw new Error('Invalid parameter');
    }

    const questionMap = new Map<string, string[]>();
    questions.forEach((question) => {
      questionMap.set(question._id, question.correct);
    });

    const score = userAnswers.reduce((acc, userAnswer) => {
      const question = questionMap.get(userAnswer._id);
      if (question) {
        const correct = question.join('');
        const userCorrect = userAnswer.correct.sort().join('');

        if (correct === userCorrect) {
          acc += 1;
        }
      }

      return acc;
    }, 0);

    response.json({
      account: foundEntryCode.account,
      totalScore: questions.length,
      score,
      status: (score / questions.length) * 100 >= foundEntryCode.passScore
    });
  } catch (error) {
    response.status(400).json({
      message: error.message
    });
  }
});

app.listen(port);

console.log('Quiz-api is listening on port ' + port);
