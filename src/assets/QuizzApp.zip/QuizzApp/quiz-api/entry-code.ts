export interface EntryCode {
  id: number;
  testName: string;
  code: string;
  account: Account;
  duration: number;
  passScore: number;
}

interface Account {
  name: string;
  clazz: string;
}
