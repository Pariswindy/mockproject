export interface UserAnswer {
  _id: string;
  correct: string[];
}